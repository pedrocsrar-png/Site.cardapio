// Churrascaria e Pizzaria Avenida — servidor sem dependências externas (Node >= 22.5)
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const PORT=process.env.PORT||3000,PUB=__dirname,DATA=path.join(__dirname,'data');
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'',REVIEW_MODE=process.env.REVIEW_MODE||'auto'; // auto | moderate
fs.mkdirSync(DATA,{recursive:true});const UP=path.join(DATA,'uploads');fs.mkdirSync(UP,{recursive:true});
const sf=path.join(DATA,'secret');if(!fs.existsSync(sf))fs.writeFileSync(sf,crypto.randomBytes(32).toString('hex'));
const SECRET=process.env.SESSION_SECRET||fs.readFileSync(sf,'utf8');
const db=new DatabaseSync(path.join(DATA,'avenida.db'));
db.exec(`CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT NOT NULL,cat TEXT,descr TEXT,price_cents INTEGER,available INTEGER DEFAULT 1,published INTEGER DEFAULT 1,sort INTEGER DEFAULT 0,image TEXT);
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY AUTOINCREMENT,product TEXT NOT NULL,stars INTEGER NOT NULL,name TEXT NOT NULL,text TEXT NOT NULL,status TEXT NOT NULL,ts INTEGER NOT NULL,iph TEXT,reports INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
CREATE INDEX IF NOT EXISTS rv ON reviews(product,status,ts);`);
if(!db.prepare('SELECT COUNT(*) c FROM products').get().c){
 const ins=db.prepare('INSERT INTO products(id,name,cat,descr,available,published,sort,image) VALUES(?,?,?,?,?,?,?,?)');
 ins.run('pizza','Pizza da casa','Pizzas','Pizza em duas metades: uma com queijo e temperos, outra com rodelas de tomate.',1,1,1,'/img/pizza.jpg');
 ins.run('galeto','Galeto completo','Galeto','Galeto assado servido em travessa, com acompanhamentos.',1,1,2,'/img/galeto.jpg');
 ins.run('carne','Carne assada (churrasco)','Churrasco','Corte de carne assada na brasa, servido no prato.',1,1,3,'/img/carne.jpg');
}
const DEF={whatsapp:'5581995024545',phone1:'(81) 99502-4545',phone2:'(81) 97506-6899',address:'Rua Dr. Severino Pinheiro, 337 — Dt. Severino Pinheiro, Limoeiro — PE, 55700-000',hours:'Fecha às 23h. Demais horários: consulte por telefone.',google_review_url:'',google_profile_url:''};
const settings=()=>{const o={...DEF};for(const r of db.prepare('SELECT k,v FROM settings').all())if(r.k in DEF)o[r.k]=r.v;return o};
// ---------- utilidades
const hits=new Map();
function limited(key,max,winMs){const n=Date.now(),a=(hits.get(key)||[]).filter(t=>n-t<winMs);if(a.length>=max){hits.set(key,a);return true}a.push(n);hits.set(key,a);return false}
const ipOf=r=>process.env.TRUST_PROXY?String(r.headers['x-forwarded-for']||'').split(',')[0].trim()||r.socket.remoteAddress:r.socket.remoteAddress;
const hash=s=>crypto.createHmac('sha256',SECRET).update(String(s)).digest('hex');
const sign=exp=>{const p=String(exp);return p+'.'+hash('s'+p)};
const authed=r=>{const m=/(?:^|; )adm=([^;]+)/.exec(r.headers.cookie||'');if(!m)return false;const[e,s]=m[1].split('.');return +e>Date.now()&&s&&s.length===64&&crypto.timingSafeEqual(Buffer.from(s),Buffer.from(hash('s'+e)))};
const send=(res,code,obj,h={})=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...h});res.end(JSON.stringify(obj))};
const body=r=>new Promise((ok,no)=>{let b='',n=0;r.on('data',c=>{n+=c.length;if(n>7e6){no(new Error('big'));r.destroy()}else b+=c});r.on('end',()=>{try{ok(b?JSON.parse(b):{})}catch(e){no(e)}});r.on('error',no)});
const clean=(s,max)=>String(s??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').trim().slice(0,max);
const pubProduct=p=>{const a=db.prepare("SELECT AVG(stars) a,COUNT(*) c FROM reviews WHERE product=? AND status='approved'").get(p.id);return{id:p.id,name:p.name,cat:p.cat,descr:p.descr,price_cents:p.price_cents,available:!!p.available,image:p.image,avg:a.c?Math.round(a.a*10)/10:0,count:a.c}};
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.jpg':'image/jpeg','.png':'image/png','.webp':'image/webp','.xml':'application/xml','.txt':'text/plain','.svg':'image/svg+xml'};
const SEC={'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'"};
// ---------- API
async function api(req,res,u){
 const m=req.method,p=u.pathname,ip=ipOf(req);
 if(m==='GET'&&p==='/api/products')return send(res,200,db.prepare('SELECT * FROM products WHERE published=1 ORDER BY sort,name').all().map(pubProduct));
 let mm;
 if(m==='GET'&&p==='/api/settings')return send(res,200,settings());
 if(m==='GET'&&p==='/api/reviews'){const pr=u.searchParams.get('product'),st=+u.searchParams.get('stars')||0,off=+u.searchParams.get('offset')||0,asc=u.searchParams.get('order')==='old';
  let q="SELECT id,stars,name,text,ts FROM reviews WHERE product=? AND status='approved'"+(st>=1&&st<=5?' AND stars='+st:'')+' ORDER BY ts '+(asc?'ASC':'DESC')+' LIMIT 10 OFFSET ?';
  return send(res,200,db.prepare(q).all(pr||'',off))}
 if(m==='POST'&&p==='/api/reviews'){const b=await body(req);
  if(b.website)return send(res,200,{ok:true,status:'pending'}); // honeypot
  if(limited('rv:'+ip,5,3600e3))return send(res,429,{error:'Muitas avaliações enviadas. Tente mais tarde.'});
  const pr=db.prepare('SELECT id FROM products WHERE id=? AND published=1').get(clean(b.product,60));if(!pr)return send(res,400,{error:'Prato inválido.'});
  const stars=+b.stars,name=clean(b.name,40),text=clean(b.text,500);
  if(!Number.isInteger(stars)||stars<1||stars>5)return send(res,400,{error:'Escolha de 1 a 5 estrelas.'});
  if(name.length<2)return send(res,400,{error:'Informe seu nome.'});if(text.length<5)return send(res,400,{error:'Escreva um comentário.'});
  if(/https?:|www\.|\.com\b|\d{8,}/i.test(name+' '+text))return send(res,400,{error:'Não use links ou números de telefone.'});
  const iph=hash(ip);
  if(db.prepare('SELECT 1 FROM reviews WHERE product=? AND (iph=? OR text=?) AND ts>?').get(pr.id,iph,text,Date.now()-864e5))return send(res,409,{error:'Você já avaliou este prato hoje.'});
  const status=REVIEW_MODE==='moderate'?'pending':'approved';
  db.prepare('INSERT INTO reviews(product,stars,name,text,status,ts,iph) VALUES(?,?,?,?,?,?,?)').run(pr.id,stars,name,text,status,Date.now(),iph);
  return send(res,201,{ok:true,status})}
 if(m==='POST'&&(mm=/^\/api\/reviews\/(\d+)\/report$/.exec(p))){if(limited('rp:'+ip,10,3600e3))return send(res,429,{error:'Limite atingido.'});db.prepare('UPDATE reviews SET reports=reports+1 WHERE id=?').run(+mm[1]);return send(res,200,{ok:true})}
 if(m==='POST'&&p==='/api/login'){const b=await body(req);
  if(limited('lg:'+ip,8,900e3))return send(res,429,{error:'Muitas tentativas. Aguarde 15 minutos.'});
  if(!ADMIN_PASSWORD)return send(res,503,{error:'ADMIN_PASSWORD não configurada no servidor.'});
  const a=Buffer.from(hash(String(b.password||''))),c=Buffer.from(hash(ADMIN_PASSWORD));
  if(!crypto.timingSafeEqual(a,c))return send(res,401,{error:'Senha incorreta.'});
  return send(res,200,{ok:true},{'Set-Cookie':`adm=${sign(Date.now()+12*3600e3)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${process.env.INSECURE_COOKIE?'':'; Secure'}`})}
 if(m==='POST'&&p==='/api/logout')return send(res,200,{ok:true},{'Set-Cookie':'adm=; HttpOnly; Path=/; Max-Age=0'});
 if(!p.startsWith('/api/admin/'))return send(res,404,{error:'Não encontrado'});
 if(!authed(req))return send(res,401,{error:'Não autorizado'});
 if(m==='GET'&&p==='/api/admin/products')return send(res,200,db.prepare('SELECT * FROM products ORDER BY sort,name').all().map(x=>({...x,...pubProduct(x),published:!!x.published,pending:db.prepare("SELECT COUNT(*) c FROM reviews WHERE product=? AND status='pending'").get(x.id).c})));
 if(m==='POST'&&p==='/api/admin/products'){const b=await body(req);const name=clean(b.name,80);if(!name)return send(res,400,{error:'Nome obrigatório'});
  let id=clean(b.id,40).toLowerCase().replace(/[^a-z0-9-]/g,'')||name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  const cents=b.price===''||b.price==null?null:Math.round(parseFloat(String(b.price).replace(',','.'))*100);if(cents!=null&&(!(cents>=0)||cents>1e7))return send(res,400,{error:'Preço inválido'});
  const ex=db.prepare('SELECT id FROM products WHERE id=?').get(id);
  if(ex)db.prepare('UPDATE products SET name=?,cat=?,descr=?,price_cents=?,available=?,published=?,sort=? WHERE id=?').run(name,clean(b.cat,40),clean(b.descr,600),cents,b.available?1:0,b.published?1:0,+b.sort||0,id);
  else db.prepare('INSERT INTO products(id,name,cat,descr,price_cents,available,published,sort) VALUES(?,?,?,?,?,?,?,?)').run(id,name,clean(b.cat,40),clean(b.descr,600),cents,b.available?1:0,b.published?1:0,+b.sort||0);
  return send(res,200,{ok:true,id})}
 if(m==='POST'&&(mm=/^\/api\/admin\/products\/([a-z0-9-]+)\/image$/.exec(p))){const b=await body(req);const x=/^data:image\/(jpeg|png|webp);base64,(.+)$/.exec(b.data||'');if(!x)return send(res,400,{error:'Imagem inválida'});
  const buf=Buffer.from(x[2],'base64');if(buf.length>5e6)return send(res,400,{error:'Imagem muito grande (máx. 5 MB)'});
  const ok=(x[1]==='jpeg'&&buf[0]===0xff&&buf[1]===0xd8)||(x[1]==='png'&&buf[0]===0x89&&buf[1]===0x50)||(x[1]==='webp'&&buf.slice(0,4).toString()==='RIFF');if(!ok)return send(res,400,{error:'Arquivo não é uma imagem válida'});
  const ext={jpeg:'jpg',png:'png',webp:'webp'}[x[1]],f=`${mm[1]}-${Date.now()}.${ext}`;fs.writeFileSync(path.join(UP,f),buf);
  db.prepare('UPDATE products SET image=? WHERE id=?').run('/uploads/'+f,mm[1]);return send(res,200,{ok:true,image:'/uploads/'+f})}
 if(m==='DELETE'&&(mm=/^\/api\/admin\/products\/([a-z0-9-]+)$/.exec(p))){db.prepare('UPDATE products SET published=0,available=0 WHERE id=?').run(mm[1]);return send(res,200,{ok:true,archived:true})}
 if(m==='GET'&&p==='/api/admin/reviews'){const st=u.searchParams.get('status');return send(res,200,db.prepare('SELECT r.id,r.product,r.stars,r.name,r.text,r.status,r.ts,r.reports,p.name pname FROM reviews r LEFT JOIN products p ON p.id=r.product '+(st?'WHERE r.status=? ':'')+'ORDER BY (r.reports>0) DESC,r.ts DESC LIMIT 200').all(...(st?[st]:[])))}
 if(m==='POST'&&(mm=/^\/api\/admin\/reviews\/(\d+)$/.exec(p))){const b=await body(req);if(!['approved','rejected','hidden','pending'].includes(b.status))return send(res,400,{error:'Status inválido'});db.prepare('UPDATE reviews SET status=?,reports=CASE WHEN ?=\'approved\' THEN 0 ELSE reports END WHERE id=?').run(b.status,b.status,+mm[1]);return send(res,200,{ok:true})}
 if(m==='GET'&&p==='/api/admin/settings')return send(res,200,settings());
 if(m==='POST'&&p==='/api/admin/settings'){const b=await body(req);const up=db.prepare('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v');
  for(const k in DEF){if(!(k in b))continue;let v=clean(b[k],300);if(k==='whatsapp')v=v.replace(/\D/g,'');if(k==='whatsapp'&&!/^\d{12,13}$/.test(v))return send(res,400,{error:'WhatsApp: use DDI+DDD+número, ex.: 5581995024545'});if(k.endsWith('_url')&&v&&!/^https:\/\//.test(v))return send(res,400,{error:'Links devem começar com https://'});up.run(k,v)}
  return send(res,200,{ok:true})}
 if(m==='GET'&&p==='/api/admin/stats')return send(res,200,{reviews:db.prepare('SELECT status,COUNT(*) c FROM reviews GROUP BY status').all(),perProduct:db.prepare("SELECT p.name,COUNT(r.id) c,ROUND(AVG(r.stars),2) a FROM products p LEFT JOIN reviews r ON r.product=p.id AND r.status='approved' GROUP BY p.id").all()});
 return send(res,404,{error:'Não encontrado'})}
// ---------- servidor
http.createServer(async(req,res)=>{
 try{const u=new URL(req.url,'http://x');for(const k in SEC)res.setHeader(k,SEC[k]);
  if(u.pathname.startsWith('/api/')){if(['POST','PUT','DELETE'].includes(req.method)){const o=req.headers.origin;if(o&&new URL(o).host!==req.headers.host)return send(res,403,{error:'Origem inválida'})}return await api(req,res,u)}
  if(u.pathname==='/sitemap.xml'){const base=process.env.PUBLIC_URL||'http://'+req.headers.host;res.writeHead(200,{'Content-Type':'application/xml'});return res.end(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${base}/</loc></url><url><loc>${base}/privacidade</loc></url></urlset>`)}
  let f=u.pathname==='/'?'/index.html':u.pathname==='/admin'?'/admin.html':u.pathname==='/privacidade'?'/privacidade.html':decodeURIComponent(u.pathname);
  const up=f.startsWith('/uploads/');if(f.startsWith('/img/'))f='/img-'+f.slice(5);
  const root=up?UP:PUB,fp=path.normalize(path.join(root,up?f.slice(9):f)),bn=path.basename(fp);
  if(!fp.startsWith(root+path.sep)||(!up&&!/^(index|admin|404|privacidade)\.html$|^robots\.txt$|^img-[a-z]+\.jpg$/.test(bn))||!fs.existsSync(fp)||!fs.statSync(fp).isFile()){res.writeHead(404,{'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(path.join(PUB,'404.html')))}
  res.writeHead(200,{'Content-Type':mime[path.extname(fp)]||'application/octet-stream','Cache-Control':f.startsWith('/uploads')||f.startsWith('/img')?'public, max-age=86400':'no-cache'});fs.createReadStream(fp).pipe(res);
 }catch(e){console.error(e);if(!res.headersSent)send(res,500,{error:'Erro interno'});else res.end()}
}).listen(PORT,()=>console.log('Avenida no ar: http://localhost:'+PORT+(ADMIN_PASSWORD?'':'  (ATENÇÃO: defina ADMIN_PASSWORD para usar o /admin)')));
